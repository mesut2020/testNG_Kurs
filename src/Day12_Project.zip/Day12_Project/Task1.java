package Day12_Project;


import org.testng.Assert;
import org.testng.annotations.Test;

public class Task1 extends BaseDriverProject2 {
@Test
    public void testSubmitMessage(){
        TestNGProjectElements testNGProjectElements = new TestNGProjectElements(driver);

        testNGProjectElements.contactUs.click();
        testNGProjectElements.enquiryTextBox.sendKeys("Burdan bir garip mi gecti dersiniz...");
        testNGProjectElements.submitButton.click();

        String actualMessage = testNGProjectElements.submitMessage.getText();
        Assert.assertTrue(actualMessage.contains("successfully"));
    }
}
